document.body.textContent = "";

let header = document.createElement('h1');
header.textContent = "this page has been eaten";
document.body.appendChild(header);